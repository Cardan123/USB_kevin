#!/bin/bash
make
./vec
