#!/bin/bash
make
./vec < inputs.txt
