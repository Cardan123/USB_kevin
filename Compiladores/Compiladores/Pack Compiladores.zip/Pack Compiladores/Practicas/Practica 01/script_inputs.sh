#!/bin/bash

./vec < inputs.txt
