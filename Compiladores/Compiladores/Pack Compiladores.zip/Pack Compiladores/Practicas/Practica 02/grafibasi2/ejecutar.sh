#!/bin/bash

java Parser
