import java.awt.*;

interface Dibujable {
	public void dibuja(Graphics g);
} 
